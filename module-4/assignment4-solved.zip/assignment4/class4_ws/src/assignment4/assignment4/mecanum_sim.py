import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, TransformStamped, Quaternion
from std_msgs.msg import Float64
from nav_msgs.msg import Odometry
from tf2_ros import TransformBroadcaster
import numpy as np
import math
from assignment4.assignment4 import Mecanum

def quaternion_from_euler(roll, pitch, yaw):
    """
    Converts euler roll, pitch, yaw to quaternion (w in last place).
    """
    cy = math.cos(yaw * 0.5)
    sy = math.sin(yaw * 0.5)
    cp = math.cos(pitch * 0.5)
    sp = math.sin(pitch * 0.5)
    cr = math.cos(roll * 0.5)
    sr = math.sin(roll * 0.5)

    q = [0] * 4
    q[0] = cy * cp * cr + sy * sp * sr
    q[1] = cy * cp * sr - sy * sp * cr
    q[2] = sy * cp * sr + cy * sp * cr
    q[3] = sy * cp * cr - cy * sp * sr

    return q

class MecanumSim(Node):
    def __init__(self):
        super().__init__('mecanum_sim')
        
        # Initialize Mecanum kinematics
        # Using values from assignment4.py main() as defaults
        length = 0.3
        width = 0.15
        wheel_radius = 0.05
        roller_radius = 0.01
        roller_angle = 45/360*np.pi
        
        # Note: __init__ expects (length, width, wheel_radius, roller_angle, roller_radius)
        self.mecanum = Mecanum(length, width, wheel_radius, roller_angle, roller_radius)
        
        # Subscribers
        self.subscription = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.cmd_vel_callback,
            10)
        
        # Publishers
        self.fl_pub = self.create_publisher(Float64, '/fl_wheel_vel_cmd', 10)
        self.fr_pub = self.create_publisher(Float64, '/fr_wheel_vel_cmd', 10)
        self.bl_pub = self.create_publisher(Float64, '/bl_wheel_vel_cmd', 10)
        self.br_pub = self.create_publisher(Float64, '/br_wheel_vel_cmd', 10)
        self.odom_pub = self.create_publisher(Odometry, '/odom', 10)
        self.tf_broadcaster = TransformBroadcaster(self)
        
        # State
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.vx = 0.0
        self.vy = 0.0
        self.vtheta = 0.0
        self.last_time = self.get_clock().now()
        
        # Timer for simulation loop
        self.timer = self.create_timer(0.1, self.timer_callback) # 10Hz
        
        self.get_logger().info('Mecanum Sim Node Started')

    def cmd_vel_callback(self, msg):
        # Extract velocities from Twist message (body frame)
        vx = msg.linear.x
        vy = msg.linear.y
        wz = msg.angular.z
        
        # Update desired velocities
        self.vx = vx
        self.vy = vy
        self.vtheta = wz
        
        # Create velocity vector [vx, vy, wz]
        # Since cmd_vel is in body frame, we pass x=[0,0,0] (theta=0) to inverse()
        # so that the "global" velocity is treated as body velocity.
        v_desired = np.array([vx, vy, wz])
        x_dummy = np.array([0.0, 0.0, 0.0])
        
        # Compute wheel velocities
        u = self.mecanum.inverse(x_dummy, v_desired)
        
        # Publish wheel velocities
        self.publish_wheel_vel(self.fl_pub, u[0])
        self.publish_wheel_vel(self.fr_pub, u[1])
        self.publish_wheel_vel(self.bl_pub, u[2])
        self.publish_wheel_vel(self.br_pub, u[3])

    def publish_wheel_vel(self, publisher, value):
        msg = Float64()
        msg.data = float(value)
        publisher.publish(msg)

    def timer_callback(self):
        current_time = self.get_clock().now()
        dt = (current_time - self.last_time).nanoseconds / 1e9
        self.last_time = current_time
        
        # Integrate position
        # Transform body velocity to global frame
        # v_x_global = v_x_body * cos(theta) - v_y_body * sin(theta)
        # v_y_global = v_x_body * sin(theta) + v_y_body * cos(theta)
        
        c = math.cos(self.theta)
        s = math.sin(self.theta)
        
        dx = (self.vx * c - self.vy * s) * dt
        dy = (self.vx * s + self.vy * c) * dt
        dtheta = self.vtheta * dt
        
        self.x += dx
        self.y += dy
        self.theta += dtheta
        
        # Publish Odometry
        q = quaternion_from_euler(0, 0, self.theta)
        
        odom = Odometry()
        odom.header.stamp = current_time.to_msg()
        odom.header.frame_id = "odom"
        odom.child_frame_id = "base_link"
        
        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.position.z = 0.0
        odom.pose.pose.orientation.x = q[0]
        odom.pose.pose.orientation.y = q[1]
        odom.pose.pose.orientation.z = q[2]
        odom.pose.pose.orientation.w = q[3]
        
        odom.twist.twist.linear.x = self.vx
        odom.twist.twist.linear.y = self.vy
        odom.twist.twist.angular.z = self.vtheta
        
        self.odom_pub.publish(odom)
        
        # Publish TF
        t = TransformStamped()
        t.header.stamp = current_time.to_msg()
        t.header.frame_id = "odom"
        t.child_frame_id = "base_link"
        
        t.transform.translation.x = self.x
        t.transform.translation.y = self.y
        t.transform.translation.z = 0.0
        t.transform.rotation.x = q[0]
        t.transform.rotation.y = q[1]
        t.transform.rotation.z = q[2]
        t.transform.rotation.w = q[3]
        
        self.tf_broadcaster.sendTransform(t)

def main(args=None):
    rclpy.init(args=args)
    node = MecanumSim()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
