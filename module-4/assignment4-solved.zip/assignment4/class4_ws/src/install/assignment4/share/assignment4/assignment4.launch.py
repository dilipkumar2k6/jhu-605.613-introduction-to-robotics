from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='assignment4',
            executable='mecanum_sim',
            name='mecanum_sim',
            output='screen',
            parameters=[
                # Add parameters here if needed, e.g.
                # {'wheel_radius': 0.05}
            ]
        ),
        Node(
            package='joy',
            executable='joy_node',
            name='joy_node',
            output='screen'
        ),
        Node(
            package='teleop_twist_joy',
            executable='teleop_node',
            name='teleop_twist_joy_node',
            output='screen',
            parameters=[
                {'enable_button': 0},  # Usually button 0 (A) or 4 (LB) is enable
                {'axis_linear.x': 1},  # Left stick vertical
                {'axis_angular.yaw': 0}, # Left stick horizontal
                {'scale_linear.x': 0.5},
                {'scale_angular.yaw': 0.5}
            ]
        )
    ])
