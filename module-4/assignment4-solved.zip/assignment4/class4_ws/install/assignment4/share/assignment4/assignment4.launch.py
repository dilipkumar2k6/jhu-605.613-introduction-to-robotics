import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    pkg_share = get_package_share_directory('assignment4')
    urdf_file = os.path.join(pkg_share, 'urdf', 'mecanum.urdf')
    with open(urdf_file, 'r') as infp:
        robot_desc = infp.read()

    return LaunchDescription([
        Node(
            package='assignment4',
            executable='mecanum_sim',
            name='mecanum_sim',
            output='screen',
            parameters=[
                # Add parameters here if needed, e.g.
                # {'wheel_radius': 0.05}
            ]
        ),
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': robot_desc}],
            arguments=[urdf_file]
        ),
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            output='screen',
            arguments=['-d', os.path.join(pkg_share, 'rviz', 'mecanum.rviz')]
        ),
        Node(
            package='joy',
            executable='joy_node',
            name='joy_node',
            output='screen'
        ),
        Node(
            package='teleop_twist_joy',
            executable='teleop_node',
            name='teleop_twist_joy_node',
            output='screen',
            parameters=[
                {'enable_button': 0},  # Usually button 0 (A) or 4 (LB) is enable
                {'axis_linear.x': 1},  # Left stick vertical
                {'axis_angular.yaw': 0}, # Left stick horizontal
                {'scale_linear.x': 0.5},
                {'scale_angular.yaw': 0.5}
            ]
        )
    ])
