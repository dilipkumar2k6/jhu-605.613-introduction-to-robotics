
import numpy as np
from assignment3 import hr_matrix, inverse_hr_matrix

def test_inverse_hr_matrix():
    # Test case 1: Identity transformation
    k = np.array([0, 0, 1])
    t = np.array([0, 0, 0])
    q = 0.0
    
    T = hr_matrix(k, t, q)
    T_inv = inverse_hr_matrix(k, t, q)
    
    print("T (Identity):\n", T)
    print("T_inv (Identity):\n", T_inv)
    
    product = np.dot(T, T_inv)
    print("Product (should be Identity):\n", product)
    
    if np.allclose(product, np.eye(4)):
        print("Test Case 1 Passed!")
    else:
        print("Test Case 1 Failed!")

    # Test case 2: Rotation + Translation
    k = np.array([0, 0, 1])
    t = np.array([1, 2, 3])
    q = np.pi / 2
    
    T = hr_matrix(k, t, q)
    T_inv = inverse_hr_matrix(k, t, q)
    
    print("\nT (Rot+Trans):\n", T)
    print("T_inv (Rot+Trans):\n", T_inv)
    
    product = np.dot(T, T_inv)
    print("Product (should be Identity):\n", product)
    
    if np.allclose(product, np.eye(4)):
        print("Test Case 2 Passed!")
    else:
        print("Test Case 2 Failed!")

if __name__ == "__main__":
    test_inverse_hr_matrix()
