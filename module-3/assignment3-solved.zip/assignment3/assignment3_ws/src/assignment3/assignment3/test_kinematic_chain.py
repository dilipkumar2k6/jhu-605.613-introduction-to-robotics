
import numpy as np
from assignment3 import KinematicChain

def test_kinematic_chain_pose():
    # Define a simple 2-link planar arm
    # Joint 0: Rotates around Z, Translation (0,0,0)
    # Joint 1: Rotates around Z, Translation (1,0,0) (Length of link 1 is 1)
    # End effector: Translation (1,0,0) (Length of link 2 is 1)
    
    ks = np.array([
        [0, 0, 1],
        [0, 0, 1]
    ])
    ts = np.array([
        [0, 0, 0],
        [1, 0, 0]
    ])
    
    kc = KinematicChain(ks, ts)
    
    # Test Case 1: Zero angles
    # Arm should be straight along X
    # Joint 0 at (0,0,0)
    # Joint 1 at (1,0,0)
    # End effector at (2,0,0)
    Q = np.array([0.0, 0.0])
    
    p0 = kc.pose(Q, index=0)
    p1 = kc.pose(Q, index=1)
    p_eff = kc.pose(Q, index=1, p_i=np.array([1, 0, 0]))
    
    print("Q=[0,0]")
    print("Joint 0 pos:", p0)
    print("Joint 1 pos:", p1)
    print("End Effector pos:", p_eff)
    
    assert np.allclose(p0, [0, 0, 0]), "Joint 0 pos failed"
    assert np.allclose(p1, [1, 0, 0]), "Joint 1 pos failed"
    assert np.allclose(p_eff, [2, 0, 0]), "End Effector pos failed"
    print("Test Case 1 Passed!")

    # Test Case 2: 90 degrees at Joint 0
    # Arm should be along Y
    # Joint 0 at (0,0,0)
    # Joint 1 at (0,1,0)
    # End effector at (0,2,0)
    Q = np.array([np.pi/2, 0.0])
    
    p0 = kc.pose(Q, index=0)
    p1 = kc.pose(Q, index=1)
    p_eff = kc.pose(Q, index=1, p_i=np.array([1, 0, 0]))
    
    print("\nQ=[pi/2, 0]")
    print("Joint 0 pos:", p0)
    print("Joint 1 pos:", p1)
    print("End Effector pos:", p_eff)
    
    assert np.allclose(p0, [0, 0, 0]), "Joint 0 pos failed"
    assert np.allclose(p1, [0, 1, 0]), "Joint 1 pos failed"
    assert np.allclose(p_eff, [0, 2, 0]), "End Effector pos failed"
    print("Test Case 2 Passed!")
    
    # Test Case 3: 90 degrees at Joint 0, 90 degrees at Joint 1
    # Link 1 along Y, Link 2 along -X
    # Joint 0 at (0,0,0)
    # Joint 1 at (0,1,0)
    # End effector at (-1,1,0)
    Q = np.array([np.pi/2, np.pi/2])
    
    p1 = kc.pose(Q, index=1)
    p_eff = kc.pose(Q, index=1, p_i=np.array([1, 0, 0]))
    
    print("\nQ=[pi/2, pi/2]")
    print("Joint 1 pos:", p1)
    print("End Effector pos:", p_eff)
    
    assert np.allclose(p1, [0, 1, 0]), "Joint 1 pos failed"
    assert np.allclose(p_eff, [-1, 1, 0]), "End Effector pos failed"
    print("Test Case 3 Passed!")

if __name__ == "__main__":
    test_kinematic_chain_pose()
