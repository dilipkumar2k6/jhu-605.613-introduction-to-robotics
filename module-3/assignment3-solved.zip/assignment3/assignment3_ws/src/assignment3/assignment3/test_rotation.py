
import numpy as np
from assignment3.assignment3 import axis_angle_rot_matrix

def test_axis_angle_rot_matrix():
    # Test case 1: Rotation around Z-axis by 90 degrees
    k = np.array([0, 0, 1])
    q = np.pi / 2
    expected_R = np.array([
        [0, -1, 0],
        [1, 0, 0],
        [0, 0, 1]
    ])
    
    R = axis_angle_rot_matrix(k, q)
    print("Computed R:\n", R)
    print("Expected R:\n", expected_R)
    
    if np.allclose(R, expected_R):
        print("Test Case 1 Passed!")
    else:
        print("Test Case 1 Failed!")

    # Test case 2: Rotation around X-axis by 90 degrees
    k = np.array([1, 0, 0])
    q = np.pi / 2
    expected_R = np.array([
        [1, 0, 0],
        [0, 0, -1],
        [0, 1, 0]
    ])
    
    R = axis_angle_rot_matrix(k, q)
    print("\nComputed R (X-axis):\n", R)
    
    if np.allclose(R, expected_R):
        print("Test Case 2 Passed!")
    else:
        print("Test Case 2 Failed!")

if __name__ == "__main__":
    test_axis_angle_rot_matrix()
