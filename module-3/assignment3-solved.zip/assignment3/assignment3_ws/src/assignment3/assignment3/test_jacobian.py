
import numpy as np
from assignment3 import KinematicChain

def test_jacobian():
    # Define a simple 2-link planar arm
    # Joint 0: Rotates around Z, Translation (0,0,0)
    # Joint 1: Rotates around Z, Translation (1,0,0)
    # End effector: Translation (1,0,0) from Joint 1
    
    ks = np.array([
        [0, 0, 1],
        [0, 0, 1]
    ])
    ts = np.array([
        [0, 0, 0], # Joint 0 at origin
        [1, 0, 0]  # Joint 1 at 1.0 along X (relative to Joint 0)
    ])
    
    kc = KinematicChain(ks, ts)
    
    # Test Case 1: Zero angles (Arm straight along X)
    # Q = [0, 0]
    # End Effector Pos (p_eff) = [2, 0, 0] (Link 0 length 1 + Link 1 length 1)
    # Wait, if ts[0]=0, Link 0 starts at 0. Joint 1 is at ts[1]=1.
    # So Link 0 has length 1.
    # p_eff_N=[1,0,0]. So Link 1 has length 1.
    # Total length 2.
    # Joint 0 (p_0) = [0, 0, 0], Axis z_0 = [0, 0, 1]
    # Joint 1 (p_1) = [1, 0, 0], Axis z_1 = [0, 0, 1]
    # J_0 = z_0 x (p_eff - p_0) = [0,0,1] x [2,0,0] = [0, 2, 0]
    # J_1 = z_1 x (p_eff - p_1) = [0,0,1] x ([2,0,0] - [1,0,0]) = [0,0,1] x [1,0,0] = [0, 1, 0]
    
    Q = np.array([0.0, 0.0])
    p_eff_N = np.array([1, 0, 0]) # End effector offset from last joint
    
    J = kc.jacobian(Q, p_eff_N)
    
    expected_J = np.array([
        [0, 0],
        [2, 1],
        [0, 0]
    ])
    
    print("Q=[0,0]")
    print("Computed J:\n", J)
    print("Expected J:\n", expected_J)
    
    assert np.allclose(J, expected_J), "Jacobian failed for Q=[0,0]"
    print("Test Case 1 Passed!")

    # Test Case 2: 90 degrees at Joint 0 (Arm along Y)
    # Q = [pi/2, 0]
    # T_0 = Trans(0) * Rot(90). Pos=[0,0,0].
    # T_1 = Trans(1) * Rot(0). Pos=[1,0,0] (relative to T_0).
    # T_total = T_0 * T_1.
    # Rot(90) * Trans(1) = Rot(90) * [[I, t1], [0,1]] = [[R, R*t1], [0,1]].
    # R*t1 = [0,1,0].
    # Pos_1 = [0,1,0].
    # End Eff (p_eff_N=[1,0,0]).
    # P_global = T_total * [1,0,0].
    # T_total = [[R0, R0*t1], [0,1]].
    # P_global = R0 * [1,0,0] + R0*t1 = [0,1,0] + [0,1,0] = [0,2,0].
    # Joint 0 at [0,0,0]. z_0=[0,0,1].
    # Joint 1 at [0,1,0]. z_1=[0,0,1].
    # J_0 = [0,0,1] x [0,2,0] = [-2, 0, 0].
    # J_1 = [0,0,1] x ([0,2,0] - [0,1,0]) = [0,0,1] x [0,1,0] = [-1, 0, 0].
    
    Q = np.array([np.pi/2, 0.0])
    J = kc.jacobian(Q, p_eff_N)
    
    expected_J = np.array([
        [-2, -1],
        [0, 0],
        [0, 0]
    ])
    
    print("\nQ=[pi/2, 0]")
    print("Computed J:\n", J)
    print("Expected J:\n", expected_J)
    
    assert np.allclose(J, expected_J), "Jacobian failed for Q=[pi/2, 0]"
    print("Test Case 2 Passed!")

if __name__ == "__main__":
    test_jacobian()
