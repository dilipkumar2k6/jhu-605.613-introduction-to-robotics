
import numpy as np
from assignment3 import hr_matrix

def test_hr_matrix():
    # Test case 1: Identity transformation (no rotation, no translation)
    k = np.array([0, 0, 1])
    t = np.array([0, 0, 0])
    q = 0.0
    expected_T = np.eye(4)
    
    T = hr_matrix(k, t, q)
    print("Computed T (Identity):\n", T)
    
    if np.allclose(T, expected_T):
        print("Test Case 1 Passed!")
    else:
        print("Test Case 1 Failed!")

    # Test case 2: Pure translation
    k = np.array([0, 0, 1])
    t = np.array([1, 2, 3])
    q = 0.0
    expected_T = np.eye(4)
    expected_T[:3, 3] = t
    
    T = hr_matrix(k, t, q)
    print("\nComputed T (Translation):\n", T)
    
    if np.allclose(T, expected_T):
        print("Test Case 2 Passed!")
    else:
        print("Test Case 2 Failed!")

    # Test case 3: Rotation around Z by 90 degrees + Translation
    k = np.array([0, 0, 1])
    t = np.array([1, 0, 0])
    q = np.pi / 2
    # Rotation part:
    # [[0, -1, 0],
    #  [1,  0, 0],
    #  [0,  0, 1]]
    expected_T = np.array([
        [0, -1, 0, 1],
        [1,  0, 0, 0],
        [0,  0, 1, 0],
        [0,  0, 0, 1]
    ])
    
    T = hr_matrix(k, t, q)
    print("\nComputed T (Rot+Trans):\n", T)
    
    if np.allclose(T, expected_T):
        print("Test Case 3 Passed!")
    else:
        print("Test Case 3 Failed!")

if __name__ == "__main__":
    test_hr_matrix()
