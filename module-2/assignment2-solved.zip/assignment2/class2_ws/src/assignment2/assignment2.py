
''' ####################
    EN605.613 - Introduction to Robotics
    Assignment 2
    Coordinate Transforms
    -------
    For this assignment you must implement the all the functions in this file
    ==================================
    Copyright 2022,
    The Johns Hopkins University Applied Physics Laboratory LLC (JHU/APL).
    All Rights Reserved.
    #################### '''

from typing import Tuple
import numpy as np


def euler_rotation_matrix(alpha: float,beta: float,gamma:float) -> np.ndarray:
    """
    15 pts
    Creates a 3x3 rotation matrix in 3D space from euler angles

    Input
    :param alpha: The roll angle (radians)
    :param beta: The pitch angle (radians)
    :param gamma: The yaw angle (radians)

    Output
    :return: A 3x3 element matix containing the rotation matrix

    """
    
    # Precompute sines and cosines
    ca = np.cos(alpha)
    sa = np.sin(alpha)
    cb = np.cos(beta)
    sb = np.sin(beta)
    cg = np.cos(gamma)
    sg = np.sin(gamma)

    # Rotation around X-axis (Roll)
    Rx = np.array([
        [1, 0, 0],
        [0, ca, -sa],
        [0, sa, ca]
    ])

    # Rotation around Y-axis (Pitch)
    Ry = np.array([
        [cb, 0, sb],
        [0, 1, 0],
        [-sb, 0, cb]
    ])

    # Rotation around Z-axis (Yaw)
    Rz = np.array([
        [cg, -sg, 0],
        [sg, cg, 0],
        [0, 0, 1]
    ])

    # Combined Rotation R = Rz * Ry * Rx
    R = Rz @ Ry @ Rx

    return R

def quaternion_rotation_matrix(Q: np.ndarray) -> np.ndarray:
    """
    15 pts
    Creates a 3x3 rotation matrix in 3D space from a quaternion.

    Input
    :param q: A 4 element array containing the quaternion (q0,q1,q2,q3) 

    Output
    :return: A 3x3 element matix containing the rotation matrix

    """
    
    # Extract the values from Q
    q0 = Q[0]
    q1 = Q[1]
    q2 = Q[2]
    q3 = Q[3]
    
    # First row of the rotation matrix
    r00 = 2 * (q0 * q0 + q1 * q1) - 1
    r01 = 2 * (q1 * q2 - q0 * q3)
    r02 = 2 * (q1 * q3 + q0 * q2)
    
    # Second row of the rotation matrix
    r10 = 2 * (q1 * q2 + q0 * q3)
    r11 = 2 * (q0 * q0 + q2 * q2) - 1
    r12 = 2 * (q2 * q3 - q0 * q1)
    
    # Third row of the rotation matrix
    r20 = 2 * (q1 * q3 - q0 * q2)
    r21 = 2 * (q2 * q3 + q0 * q1)
    r22 = 2 * (q0 * q0 + q3 * q3) - 1
    
    # 3x3 rotation matrix
    rot_matrix = np.array([[r00, r01, r02],
                           [r10, r11, r12],
                           [r20, r21, r22]])
                            
    return rot_matrix

def quaternion_multiply(Q0: np.ndarray,Q1: np.ndarray) -> np.ndarray:
    """
    15 pts
    Multiplies two quaternions.

    Input
    :param Q0: A 4 element array containing the first quaternion (q01,q11,q21,q31) 
    :param Q1: A 4 element array containing the second quaternion (q02,q12,q22,q32) 

    Output
    :return: A 4 element array containing the final quaternion (q03,q13,q23,q33) 

    """
    
    # Extract values from Q0
    w0 = Q0[0]
    x0 = Q0[1]
    y0 = Q0[2]
    z0 = Q0[3]
    
    # Extract values from Q1
    w1 = Q1[0]
    x1 = Q1[1]
    y1 = Q1[2]
    z1 = Q1[3]
    
    # Computer the product of the two quaternions, term by term
    w = w0 * w1 - x0 * x1 - y0 * y1 - z0 * z1
    x = w0 * x1 + x0 * w1 + y0 * z1 - z0 * y1
    y = w0 * y1 - x0 * z1 + y0 * w1 + z0 * x1
    z = w0 * z1 + x0 * y1 - y0 * x1 + z0 * w1
    
    # Create a 4 element array containing the final quaternion
    final_quaternion = np.array([w, x, y, z])
    
    return final_quaternion


def quaternion_to_euler(Q: np.ndarray) -> np.ndarray:
    """
    15 pts
    Takes a quaternion and returns the roll, pitch yaw array.

    Input
    :param Q0: A 4 element array containing the quaternion (q01,q11,q21,q31) 

    Output
    :return: A 3 element array containing the roll,pitch, and yaw (alpha,beta,gamma) 

    """
    
    # Extract values from Q
    w = Q[0]
    x = Q[1]
    y = Q[2]
    z = Q[3]
    
    # Roll (x-axis rotation)
    sinr_cosp = 2 * (w * x + y * z)
    cosr_cosp = 1 - 2 * (x * x + y * y)
    roll = np.arctan2(sinr_cosp, cosr_cosp)
    
    # Pitch (y-axis rotation)
    sinp = 2 * (w * y - z * x)
    if abs(sinp) >= 1:
        pitch = np.sign(sinp) * np.pi / 2 # use 90 degrees if out of range
    else:
        pitch = np.arcsin(sinp)
        
    # Yaw (z-axis rotation)
    siny_cosp = 2 * (w * z + x * y)
    cosy_cosp = 1 - 2 * (y * y + z * z)
    yaw = np.arctan2(siny_cosp, cosy_cosp)
    
    return np.array([roll, pitch, yaw])


def rotate(p1: np.ndarray,alpha: float,beta: float,gamma: float) -> np.ndarray:
    """
    15 pts
    Rotates a point p1 in 3D space to a new coordinate system.

    Input
    :param p1: A 3 element array containing the original (x1,y2,z1) position]
    :param alpha: The roll angle (radians)
    :param beta: The pitch angle (radians)
    :param gamma: The yaw angle (radians)

    Output
    :return: A 3 element array containing the new rotated position (x2,y2,z2)

    """
    
    # Get the rotation matrix
    R = euler_rotation_matrix(alpha, beta, gamma)
    
    # Rotate the point
    p2 = R @ p1
    
    return p2


def inverse_rotation(p2: np.ndarray,alpha: float,beta: float,gamma: float) -> np.ndarray:
    """
    15 pts
    Inverse rotation from a point p2 in 3D space to the original coordinate system.

    Input
    :param p: A 3 element array containing the new rotated position (x2,y2,z2)
    :param alpha: The roll angle (radians)
    :param beta: The pitch angle (radians)
    :param gamma: The yaw angle (radians)

    Output
    :return: A 3 element array containing the original (x1,y1,z1) position]

    """
    
    # Get the rotation matrix
    R = euler_rotation_matrix(alpha, beta, gamma)
    
    # Inverse rotation (transpose of R)
    p1 = R.T @ p2
    
    return p1

def transform_pose(P: np.ndarray,Q: np.ndarray,T: np.ndarray,R: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """
    10 pts
    Takes a position and orientation in the original frame along with a translation and
    rotation. 

    Then converts the original point into the new coordinate system.

    Hints: 
    - Compute the quaternion that represents the new orientation by multiplying the
      old quaternion by the new quaternion (order matters!)
    - When transforming the point rotation is applied before translation

    Input
    :param P: A 3 element array containing the position (x0,y0,z0) in the original frame
    :param Q: A 4 element array containing the quaternion (q0,q1,q2,q3) 
    :param T: A 3 element array containing the vector between the origins in the two coordinate systems (dx,dy,dz) 
    :param R: A 4 element array containing the rotation in the form of a quaternion (q0,q1,q2,q3) 

    Output
    :return: New Pose, A 3 element array (x1,y2,z1) containing the position in the new coordinate frame
    :return: New Quaternion, A 4 element array containing the orientation (q0,q1,q2,q3) in the new coordinate frame

    """
    
    # Convert the rotation quaternion R to a rotation matrix
    Rot_matrix = quaternion_rotation_matrix(R)
    
    # Rotate the position P
    P_rotated = Rot_matrix @ P
    
    # Translate the position
    P_new = P_rotated + T
    
    # Compute the new orientation
    # Note: Applying the transform rotation R to the original orientation Q
    # Standard order for frame transformation is R * Q
    Q_new = quaternion_multiply(R, Q)
    
    return P_new, Q_new
