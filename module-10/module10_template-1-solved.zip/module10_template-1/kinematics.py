''' ####################
EN605.613 - Introduction to Robotics
Assignment 5
Linear Quadratice Regulator
-------
For this assignment you must implement the DifferentialDrive class, get_R, get_Q, and dLQR function.

Use the vehicle kinematics defined in Lecture 3. 

==================================
Copyright 2020,
The Johns Hopkins University Applied Physics Laboratory LLC (JHU/APL).
All Rights Reserved.

#################### '''

import sys
import numpy as np
import scipy.linalg as la
#import control

class DifferentialDrive(object):
  """
  Implementation of Differential Drive kinematics.
  This represents a two-wheeled vehicle defined by the following states
  state = [x,y,theta]
  and accepts the following control inputs
  input = [left_wheel_rotation_rate,right_wheel_rotation_rate]

  """
  def __init__(self,L=1,R=1):
    """
    Initializes the class
    Input
      :param L: The distance between the wheels
      :param R: The radius of the wheels
    """

    self.L = L
    self.R = R
    self.u_limit = 1 / R
    self.V = None
    self.k_p = 1

  def get_state_size(self):
    return 3

  def get_input_size(self):
    return 2

  def get_V(self):
    '''
    This function provides the covariance matrix V which describes the noise that can be applied to the forward kinematics.
    
    Feel free to experiment with different levels of noise.

      Output
        :return: V: input cost matrix
    '''
    if self.V is None:
        self.V = np.eye(3)
        self.V[0,0] = 0.01
        self.V[1,1] = 0.01
        self.V[2,2] = 0.1
    return 1e-5*self.V

  def forward(self,x,u,v,dt):
    """
    Computes the forward kinematics for the system.

    Input
      :param x0: The starting state (position) of the system (units:[m,m,rad])
      :param u: The control input to the system (e.g. wheel rotation rates) (units: [rad/s,rad/s])
      :param v: The noise applied to the system (units:[m/s, m/s])

    Output
      :return: x1: The new state of the system

    """

    # Extract states and inputs
    theta = x[2]
    u_l = u[0]
    u_r = u[1]
    
    # Compute body velocities
    v_linear = (self.R / 2.0) * (u_l + u_r)
    w_angular = (self.R / self.L) * (u_r - u_l)
    
    # Compute state update
    x_new = x[0] + v_linear * np.cos(theta) * dt + v[0]
    y_new = x[1] + v_linear * np.sin(theta) * dt + v[1]
    theta_new = x[2] + w_angular * dt + v[2]
    
    # Normalize theta to [-pi, pi]
    theta_new = (theta_new + np.pi) % (2 * np.pi) - np.pi
    
    return np.array([x_new, y_new, theta_new])


  def linearize(self,x,u,dt=1):
    """
    Computes the first order jacobian for A and B around the state x and input u

    Input
      :param x: The state of the system 
      :param u: The control input to the system (e.g. wheel rotation rates)

    Output
      :return: A: The Jacobian of the kinematics with respect to x
      :return: B: The Jacobian of the kinematics with respect to u

    """

    # Extract states and inputs
    theta = x[2]
    u_l = u[0]
    u_r = u[1]
    
    # Pre-compute common terms
    r_half = self.R / 2.0
    v = r_half * (u_l + u_r) # Linear velocity
    
    # Compute Jacobian A (w.r.t state)
    A = np.eye(3)
    A[0, 2] = -v * np.sin(theta) * dt
    A[1, 2] =  v * np.cos(theta) * dt
    
    # Compute Jacobian B (w.r.t input)
    B = np.zeros((3, 2))
    B[0, 0] = r_half * np.cos(theta) * dt
    B[0, 1] = r_half * np.cos(theta) * dt
    B[1, 0] = r_half * np.sin(theta) * dt
    B[1, 1] = r_half * np.sin(theta) * dt
    B[2, 0] = - (self.R / self.L) * dt
    B[2, 1] =   (self.R / self.L) * dt
    
    return A, B


  def PID(self,x, x_goal,dt=1):
    """
    Computes the Proportional control for the diff drive system given
    the current state and velocity and the desired state. Do not worry about the derivative
    or integral term for this controller. 

    Input
      :param x: The state of the system 
      :param v: The current forward velocity and turn rate
      :param x_goal: The control input to the system (e.g. wheel rotation rates)
      :param dt: The timestep of the simulation
      
    Output
      :return u: The control input to the system (e.g. wheel rotation rates)
    """
    
    x_r = x[0]
    y_r = x[1]
    th_r = x[2]
    pid_length_offset = 0.1
    
    x_p  =  x_r + pid_length_offset * np.cos(th_r)
    y_p  =  y_r + pid_length_offset * np.sin(th_r)

    x_g = x_goal[0]
    y_g = x_goal[1]

    delta_x = x_p - x_g 
    delta_y = y_p - y_g 

    v_x = 0
    v_y = 0 

    vf =  - self.k_p * ( np.cos(th_r) * delta_x + np.sin(th_r) * delta_y) - self.k_p * ( np.cos(th_r) * v_x + np.sin(th_r) * v_y)

    wl = - self.k_p * ( - np.sin(th_r) * delta_x + np.cos(th_r) * delta_y) - self.k_p * ( - np.sin(th_r) * v_x + np.cos(th_r) * v_y)
 
    v_new = np.array([vf,wl])
    
    return self.inverse(x, v_new)
  
  def inverse(self,x, v):
    """
    Computes the inverse kinematics for the DiffDrive system (vehicle motion --> wheel motion).

    Input
      :param x: The starting state (position) of the system. This is [x,y,theta].
      :param v: The desired velocity vector for the system (in robots frame of reference).
                This is [speed, turn_rate] where Vtheta is the yaw rate (rotation rate around the z-axis)

    Output
      :return: u: The necessary control inputs to achieve the desired velocity vector. This is the rotation rates for each wheel [psi_dot_left,psi_dot_right] (e.g. radians per second)

    """

    psi_left  = 1 / self.R * (v[0] - self.L/2 * v[1])
    psi_right =  1 / self.R * (v[0] + self.L/2 * v[1])

    return np.array([psi_left,psi_right])
