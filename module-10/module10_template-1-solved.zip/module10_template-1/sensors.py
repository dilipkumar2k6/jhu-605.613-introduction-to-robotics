''' ####################
EN605.613 - Introduction to Robotics
Assignment 6
Extended Kalman Filter
-------
For this assignment you must implement the LandmarkDetector class and the EKF function.

Use the definition of the landmark sensor given in Lecture 7.

==================================
Copyright 2020,
The Johns Hopkins University Applied Physics Laboratory LLC (JHU/APL).
All Rights Reserved.

#################### '''

import sys
import numpy as np
import scipy.linalg as la
#import control
from numpy import dot


class LandmarkDetector(object):
  """
  Landmark sensor for the differential drive system.
  """

  def __init__(self,landmark_list):
    """
    Computes sensor measurements for a landmark sensor.

    Input
      :param landmark_list: a 2d list of landmarks [L1,L2,L3,...,LN], where each row is a 2D landmark defined by Li =[l_i_x,l_i_y]

    """

    self.landmarks = np.array(landmark_list)
    self.N_landmarks = self.landmarks.shape[0]
    self.W = None

  def get_W(self):
    '''
    This function provides the covariance matrix W which describes the noise that can be applied to the measurements.

    Feel free to experiment with different levels of noise.
    
      Output
        :return: V: input cost matrix
    '''
    if self.W is None:
      self.W = 0.095*np.eye(2*self.N_landmarks)
    return self.W


  def measure(self,x,w=None):
    """
    Computes the measurement for the system. This will be a list of range and relative angles for each landmark.

    Input
      :param x: The state [x,y,theta,speed] of the system
      :param w: The noise (assumed Gaussian) applied to the measurment 

    Output
      :return: y: The resulting measurement (2xN array). y = [h1,h2,h3...,hN] where hi=[range_i,angle_i]

    """

    x_r = x[0]
    y_r = x[1]
    theta = x[2]
    
    y = []
    for l in self.landmarks:
        dx = l[0] - x_r
        dy = l[1] - y_r
        r = np.sqrt(dx**2 + dy**2)
        phi = np.arctan2(dy, dx) - theta
        # Normalize angle to [-pi, pi]
        phi = (phi + np.pi) % (2 * np.pi) - np.pi
        y.extend([r, phi])
        
    y = np.array(y)
    
    if w is not None:
        y += w
        
    return y


  def jacobian(self,x):
    """
    Computes the first order jacobian around the state x

    Input
      :param x: The starting state (position) of the system

    Output
      :return: H: The resulting Jacobian matrix H for the sensor
      
    """

    x_r = x[0]
    y_r = x[1]
    
    H = np.zeros((2 * self.N_landmarks, 3))
    for i, l in enumerate(self.landmarks):
        dx = l[0] - x_r
        dy = l[1] - y_r
        d2 = dx**2 + dy**2
        d = np.sqrt(d2)
        
        # Range derivatives
        H[2*i, 0] = -dx / d
        H[2*i, 1] = -dy / d
        H[2*i, 2] = 0.0
        
        # Bearing derivatives
        H[2*i+1, 0] = dy / d2
        H[2*i+1, 1] = -dx / d2
        H[2*i+1, 2] = -1.0
        
    return H


def EKF(DiffDrive,Sensor,y,x_hat,sigma,u,dt,V=None,W=None):
    """
    Computes the first order jacobian around the state x.


    Some of these matrixes will be non-square or singular. Utilize the pseudo-inverse function
    la.pinv instead of inv to avoid these errors.

    Input
      :param DiffDrive: The DifferentialDrive object defined in kinematics.py
      :param Sensor: The Landmark Sensor object defined in this class
      :param y: The measurement made at time t+1
      :param x_hat: The starting estimate of the state at time t
      :param sigma: The state covariance matrix at time t
      :param u: The input to the system at time t
      :param V: The input to the system at time t
      :param V: The input to the system at time t

      :param dt: timestep size delta t

    Output
      :return: x_hat_2: The estimate of th state at time t+1
      :return: sigma_2: The state covariance matrix at time t+1
    """

    # Predict Step
    # 1. State prediction
    x_pred = DiffDrive.forward(x_hat, u, np.zeros(3), dt)
    
    # 2. Covariance prediction
    A, B = DiffDrive.linearize(x_hat, u, dt)
    if V is None:
        V = DiffDrive.get_V()
    sigma_pred = A @ sigma @ A.T + V
    
    # Update Step
    # 1. Expected measurement
    y_hat = Sensor.measure(x_pred, np.zeros(2 * Sensor.N_landmarks))
    
    # 2. Jacobian H
    H = Sensor.jacobian(x_pred)
    
    # 3. Innovation
    z = y - y_hat
    # Normalize angle differences in z (every second element starting from index 1)
    for i in range(Sensor.N_landmarks):
        phi_idx = 2 * i + 1
        z[phi_idx] = (z[phi_idx] + np.pi) % (2 * np.pi) - np.pi
        
    # 4. Innovation covariance
    if W is None:
        W = Sensor.get_W()
    S = H @ sigma_pred @ H.T + W
    
    # 5. Kalman Gain
    # Use pseudo-inverse as requested
    K = sigma_pred @ H.T @ la.pinv(S)
    
    # 6. Updated state estimate
    x_hat_2 = x_pred + K @ z
    # Normalize theta in x_hat_2
    x_hat_2[2] = (x_hat_2[2] + np.pi) % (2 * np.pi) - np.pi
    
    # 7. Updated covariance
    I = np.eye(3)
    sigma_2 = (I - K @ H) @ sigma_pred
    
    return x_hat_2, sigma_2



